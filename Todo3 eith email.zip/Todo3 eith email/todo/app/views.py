from django.shortcuts import render , redirect,HttpResponse,HttpResponseRedirect
from django.http import HttpResponse
from django.contrib.auth import authenticate , login as loginUser  , logout, update_session_auth_hash
from django.contrib.auth.forms import AuthenticationForm , PasswordChangeForm
# Create your views here.
from app.forms import TODOForm,signupForm,SetPasswordForm,forget_passwordForm,Password_rest_form
#from django.views.generic import TemplateView, FormView, CreateView
#from django.urls import reverse_lazy, reverse 
from app.models import TODO,MyCustomModel,user_otp
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
import random
from django.core.mail import send_mail
from django.conf import settings
from django.contrib import messages
from .utils import send_email
from django.contrib.auth import get_user_model
from functools import lru_cache
from django.views.decorators.cache import cache_page
from todo import settings
#User = get_user_model()


@login_required(login_url='login')
def home(request):
    if request.user.is_authenticated:
        user = request.user
        form = TODOForm()
        todos = TODO.objects.filter(user = user).order_by('priority')
        #print(todos.__dict__)
        if (request.session.has_key('uid')):
            res = request.session['uid']
            print(res)
            return render(request , 'index.html' , context={'form' : form , 'todos' : todos, })
        else:
            return redirect('login')

def login(request):
    
    if request.method == 'GET':
        form1 = AuthenticationForm()
        context = {
            "form" : form1
        }
        return render(request , 'login.html' , context=context )
    else:
        form = AuthenticationForm(data=request.POST)
        print(form.is_valid())
        
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            data=request.POST.get('username')
            #print(data)
            user = authenticate(username = username , password = password)
        

            if user is not None:
                loginUser(request , user)
                messages.success(request, f'You Have Logged In Successfully ')
                request.session['uid'] = request.POST.get('user.id') 
                return redirect('home')
        else:
            context = {
                "form" : form
            }
            return render(request , 'login.html' , context=context )

#==========================Sign_Up Verification via OTP=============================================================================================

def signup(request):

    if request.method == 'GET':
        form = signupForm()
        context = {
            "form" : form
        }
        return render(request , 'signup.html' , context=context)
    else:
        #print(request.POST)
        form = signupForm(request.POST)  
        context = {
            "form" : form
        }
        if form.is_valid():
            user = form.save()
            user.is_active=False  #now user is not active thus can,t login bec we have to verify user with OTP
            user.save()
            user_id = user.id
            print(user)
            if user is not None:
                my_otp=otp()
                print(my_otp)
                usr_otp = user_otp.objects.create(user =user, otp= my_otp)
                usr_otp.save()
                #send_email(user_id)
                messages.success(request, f'Otp Has Sent Successfully To Ur Mail.Check Ur Mail')
            return render(request, 'otp_check.html', {'otp':True, 'usr':user})
        else:
            return render(request , 'signup.html' , context=context)



def otp():
    return random.randint(100000,999999)





def verify(request):
    if request.method == 'POST':
        get_otp = request.POST.get('otp')
        if get_otp:
            get_usr = request.POST.get('usr')
            #usr = MyCustomModel.objects.get(email=request.POST.get('email'))
            usr = MyCustomModel.objects.get(email = get_usr)
        
            if int(get_otp) == user_otp.objects.filter(user=usr).last().otp:
                usr.is_active = True
                usr.save()
                messages.success(request, f'Account is Created For {usr.username}')

                return redirect('login')
            else:
                messages.warning(request, f'You Entered a Wrong OTP')
                return render(request, 'otp_check.html', {'otp': True, 'usr': usr})
        




#=====================================CRUD OPerations=============================================================================================================
@login_required(login_url='login')
def add_todo(request):
    if request.user.is_authenticated:
        user = request.user
        #print(user)
        form = TODOForm(request.POST,request.FILES)
        #print(request.POST, request.FILES) 
        if form.is_valid():
            print(form.cleaned_data)
            todo = form.save(commit=False)
            todo.user = user
            todo.save()
            #print(todo)
            return redirect("home")
        else: 
            return render(request , 'index.html' , context={'form' : form})


def delete_todo(request , id ):
    print(id)
    TODO.objects.get(pk = id).delete()
    return redirect('home')

def change_todo(request , id  , status):
    todo = TODO.objects.get(pk = id)
    todo.status = status
    todo.save()
    return redirect('home')


@login_required(login_url='login')
def change_password(request ):
    if request.user.is_authenticated:
        if request.method == 'POST':
            fm = PasswordChangeForm(user=request.user, data = request.POST)
            if fm.is_valid():
                fm.save()
                #update_session_auth_hash(request, fm.user)
            return redirect('home')
        else:
            fm = PasswordChangeForm(user = request.user)
        #user = request.user
        return render(request, 'changepass.html', {'form': fm})




def signout(request):
    request.session.clear()
    logout(request)
    return redirect('login')

#============================================Reset Password via OTP==========================================================================================================
def forget_password(request):
    if request.method == 'GET':
        form = forget_passwordForm()
        context = {
            "form" : form
        }
        return render(request , 'forget_password.html' , context=context)
    else:
        form = forget_passwordForm(request.POST)
        
        email = request.POST.get('email')
        user_email = MyCustomModel.objects.filter(email = email)
        if user_email:
            user = MyCustomModel.objects.get(email=email)
            user.is_active = False
            user.save()
            user_id = user.id
            request.session['email'] = request.POST['email']
            if user is not None:
                    my_otp =otp()
                    #user_otp.otp = my_otp
                    user_otp.objects.get(otp = my_otp)
                    user_otp.otp = my_otp
                    user_otp.save()
                    print(user_otp.otp)
                    send_email(user_id)
                    messages.success(request, f'Otp Has Sent Successfully To Ur Mail.Check Ur Mail')
                    return render(request, 'otp_check1.html', {'otp':True, 'usr':user})
        else:
            messages.warning(request,f'invalid user_email, pln enter correct email')
            return render(request, 'forget_password.html', {'form':form})

def verify1(request):
     if request.session.has_key('email'):
        email = request.session['email']
        get_otp = request.POST.get('otp')
        if get_otp:
            get_usr = request.POST.get('usr')
            usr = MyCustomModel.objects.get(email=get_usr)

            if int(get_otp) == user_otp.objects.filter(user=usr).last().otp:
                usr.is_active = True
                usr.save()
                messages.success(request, f'your Email is verified')
                return redirect('password_reset')
            else:
                messages.warning(request, f'you have entered a wrong otp')
                return render(request, 'otp_check1.html', {'otp':True, 'usr': usr})


def password_reset(request):
    if request.session.has_key('email'):
        email = request.session['email']
        print(email)
        user = MyCustomModel.objects.get(email=email)
        if request.method == 'POST':
            form = Password_rest_form(request.POST)
            new_password = request.POST.get('new_password')
            confirm_password = request.POST.get('confirm_password')
            if not new_password:
                messages.warning(request, f'Enter New Password')
            elif not confirm_password:
                messages.warning(request,f'plz Enter Your Confirm Password')
            elif new_password == user.password:
                messages.warning(request, f'Password Already Exists!!!!!Plz Enter New Password ')
            elif new_password != confirm_password:
                messages.warning(request, f'Password is not matched')
            else: 
                
                user.set_password(new_password)
                user.save()
                messages.success(request,f'Password changed successfully')
                return redirect('login')
        else:
            form = Password_rest_form()
            return render(request, 'password_reset.html', {'form':form})


            

    
    
        